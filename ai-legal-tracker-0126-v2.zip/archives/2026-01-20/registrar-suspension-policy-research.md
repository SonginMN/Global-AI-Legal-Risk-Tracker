# 域名注册商封禁政策与案例研究

**研究日期**：2026年1月20日  
**研究范围**：GoDaddy、Cloudflare Registrar、Namecheap 的封禁政策及美国、印度、欧盟相关案例

---

## 第一部分：GoDaddy 封禁政策与案例

### 1.1 GoDaddy 协议中的封禁规定

#### 1.1.1 Universal Terms of Service（通用服务条款）

**关键条款：**

> "GoDaddy Registry may, at any time … **without prior notice**, remove or otherwise act against any Unauthorized Content … including disabling a domain name … in certain exceptional circumstances (mainly under a court order)."

**解读**：在法院命令等例外情况下，GoDaddy 可以**无需事先通知**就停用域名。

🔗 **政策链接**：https://registry.godaddy/legal/

---

#### 1.1.2 Complaint Mechanisms（投诉机制）

**关键条款：**

> "GoDaddy will comply with any order issued by a court of competent jurisdiction regarding the final disposition of a customer's domain or website at issue, **regardless of whether it is named in a dispute or legal action**."

**解读**：即使 GoDaddy 未被列为案件当事人，也会执行法院命令。政策中**未明确承诺**执行前会通知持有人。

🔗 **政策链接**：https://help-center.dc-aws.godaddy.com/help/godaddy-complaint-mechanisms-40875

---

#### 1.1.3 GoDaddy Corporate Domains (GCD) 使用条款

**关键条款：**

> "Registry reserves the right to … place any domain name(s) on registry lock, hold, or other status … to comply with any applicable court orders, laws … **without notice**."

**解读**：明确写明 "without notice"，即在遵守法院命令时可不通知域名所有者。

🔗 **政策链接**：https://gcd.com/terms-of-use/

---

#### 1.1.4 关于通知的说明

**重要澄清：**

根据公开资料，GoDaddy 的域名注册服务条款中**未发现**明确承诺在法院命令执行前给予固定天数通知的条款。

上述 Universal Terms of Service 和 Complaint Mechanisms 政策均表明，GoDaddy 保留在法院命令下"without prior notice"（无需事先通知）采取行动的权利。

**注意**：GoDaddy 其他服务（如 SmartLine 虚拟电话服务）可能有不同的通知条款，但这些不适用于域名注册服务。

---

### 1.2 GoDaddy 相关案例

#### 🇺🇸 美国案例

##### 案例1：Chanel 商标案（2011年，内华达州联邦法院）

| 项目 | 内容 |
|------|------|
| **案件背景** | Chanel 起诉近 700 个销售假冒商品的网站 |
| **法院命令** | 将这些域名转移给 GoDaddy 管理，并命令 Google、Facebook、Twitter 等对这些域名进行 "de-index"（去索引化）处理 |
| **GoDaddy 角色** | 域名转移接收方和管理方 |
| **GoDaddy 采取措施** | ✅ 接收并管理被没收的域名，将域名指向警告页面 |
| **最终结果** | ✅ 近700个域名被成功没收并转移，搜索引擎完成去索引化，假冒网站被有效关闭 |

🔗 **案例链接**：https://www.wired.com/2011/11/chanel-trademark

---

##### 案例2：JotForm 被 Secret Service 通知事件（2012年）

| 项目 | 内容 |
|------|------|
| **案件背景** | GoDaddy 应美国特勤局请求暂停 JotForm.com |
| **执行方式** | 将域名的 nameservers 指向显示 "SUSPENDED-FOR-SPAM-AND-ABUSE" 的服务器 |
| **是否有法院命令** | 无公开的法院命令，仅为执法通知 |
| **是否通知持有人** | ❌ 未事先通知 |
| **GoDaddy 采取措施** | ⚠️ 立即暂停域名解析，无事先通知网站所有者 |
| **最终结果** | ⚠️ 引发公众争议，JotForm 网站在短暂中断后恢复；事件暴露了注册商在无法院命令情况下响应执法请求的问题 |

🔗 **案例链接**：https://arstechnica.com/tech-policy/2012/02/secret-service-asks-for-shutdown-of-legit-website-over-user-content-godaddy-complies/

---

##### 案例3：Leo India Films Ltd. v. GoDaddy（亚利桑那州法院）

| 项目 | 内容 |
|------|------|
| **案件背景** | GoDaddy 在接到印度执法机关通知后，暂停了域名 einthusan.tv 的服务 |
| **后续发展** | Leo India Films 起诉 GoDaddy，声称合同与侵权责任 |
| **GoDaddy 采取措施** | ⚠️ 暂停域名服务，后解锁并允许转移 |
| **最终结果** | ❌ 法院于2020年2月驳回案件，理由是 GoDaddy 服务条款中的责任限制条款使争议金额低于联邦管辖所需的 $75,000，联邦法院无管辖权 |

🔗 **案例链接**：https://www.casemine.com/judgement/us/5e535b6b4653d00b253ec7d6

---

##### 案例4：Tamaris DMCA 传票案（2025年，马里兰联邦地区法院）

| 项目 | 内容 |
|------|------|
| **案件背景** | 版权方 Tamaris 向 GoDaddy 发出 DMCA 通知，要求披露涉嫌侵权域名所有者身份 |
| **法院命令** | 要求 GoDaddy 披露 100 多个涉嫌版权侵权域名所有者的身份信息 |
| **类型** | 身份披露命令（非封禁命令） |
| **GoDaddy 采取措施** | ⚠️ 配合法院传票程序 |
| **最终结果** | ✅ 法院于2025年12月拒绝了被告 John Doe 对传票的 "motion to quash"，命令 GoDaddy 必须配合提供域名所有者信息 |

🔗 **案例链接**：https://worldjusticenews.com/news/2025/12/18/godaddy-ordered-to-unmask-owners-of-over-100-alleged-copyright-infringing-domains/

---

##### 案例5：uBID, Inc. v. GoDaddy Group（2010年，第七巡回上诉法院）

| 项目 | 内容 |
|------|------|
| **案件背景** | uBID 指控 GoDaddy 注册了与其商标相似的域名（typosquatting/cybersquatting） |
| **GoDaddy 采取措施** | ⚖️ 进行法律抗辩 |
| **最终结果** | ❌ 法院未判 GoDaddy 需大规模阻断域名服务；案件聚焦于 GoDaddy 是否违反商标法，而非封禁命令 |

🔗 **案例链接**：https://caselaw.findlaw.com/us-7th-circuit/1539590.html

---

##### 案例6：968.com 域名纠纷案（2023年）

| 项目 | 内容 |
|------|------|
| **案件背景** | 原告 Yuming Hao 主张其已合法购买域名 968.com，但 GoDaddy 锁定账号，阻止域名转让 |
| **原告诉求** | 要求 GoDaddy 解锁并确认所有权 |
| **GoDaddy 采取措施** | ⚖️ 锁定域名，进行法律抗辩 |
| **最终结果** | ❌ 法院于2023年4月驳回案件，未要求 GoDaddy 释放或转让域名 |

🔗 **案例链接**：https://domainnamewire.com/2023/04/26/court-dismisses-case-against-godaddy-over-968-com-domain/

---

#### 🇮🇳 印度案例

##### 案例1：Amul 品牌案（2020年，Delhi High Court）

| 项目 | 内容 |
|------|------|
| **原告** | Gujarat Co-operative Milk Marketing Federation（Amul 品牌所有者） |
| **案件背景** | 多个仿冒 "Amul" 的网站宣传加盟、分销等机会，涉嫌欺诈 |
| **法院命令** | 禁止 GoDaddy 等域名注册商出售带有 "Amul" 前缀或后缀的域名组合，并命令电信部、MEITY、NIXI 封锁这些网站 |
| **GoDaddy 采取措施** | ✅ 遵守法院命令，暂停相关域名注册 |
| **最终结果** | ✅ 侵权域名被停用/撤除访问权限，Amul 胜诉；注册商被禁止注册含 "Amul" 的新域名组合 |

🔗 **案例链接**：https://www.medianama.com/2020/08/223-godaddy-amul-domain-registrars-delhi-hc/

---

##### 案例2：Swiggy 商标案（2022-2023年，Bombay High Court）

| 项目 | 内容 |
|------|------|
| **案件背景** | Swiggy (Bundl Technologies Pvt Ltd) 起诉多个侵权域名 |
| **2022年11月命令** | 临时禁令（ad-interim order），要求 GoDaddy 暂停所有包含 "Swiggy" 商标的域名注册 |
| **2023年1月命令** | 改为每次注册含 Swiggy 商标的域名时，GoDaddy **必须通知 Swiggy** |
| **GoDaddy 采取措施** | ✅ 暂停已注册的侵权域名；建立通知机制 |
| **最终结果** | ⚠️ 法院拒绝持续 omnibus 型永久禁止未来注册的命令，仅保留通知义务；法院认为应对每个具体侵权域名单独申请 |

🔗 **案例链接**：
- https://www.legaleraonline.com/from-the-courts/bombay-high-court-orders-godaddy-to-notify-swiggy-whenever-a-domain-name-containing-the-mark-swiggy-is-registered-850643
- https://lawbeat.in/news-updates/bombay-hc-asks-godaddy-inform-swiggy-every-time-its-domain-registered-refuses-pass-omnibus-order
- https://www.latestlaws.com/judgements/bombay-high-court/2023/february/2023-latest-caselaw-1951-bom
- https://indiankanoon.org/doc/116900066/

---

##### 案例3：Baazi Group 赌博网站案（2025年，Delhi High Court）

| 项目 | 内容 |
|------|------|
| **原告** | Baazi Group |
| **案件背景** | 某些线上赌博网站使用侵权域名并在印度推广 |
| **法院命令** | **Ex-parte 临时禁令**，命令包括 GoDaddy 在内的注册商暂停侵权域名，并披露域名持有人信息 |
| **GoDaddy 采取措施** | ✅ 遵守法院临时禁令，暂停相关域名 |
| **最终结果** | ✅ 侵权赌博网站域名被暂停；域名持有人信息被披露给原告 |

🔗 **案例链接**：https://legal.economictimes.indiatimes.com/news/litigation/delhi-high-court-takes-action-against-infringing-gambling-websites-and-domain-names/118496817

---

##### 案例4：Delhi High Court 针对域名注册商的警告（2023年）

| 项目 | 内容 |
|------|------|
| **案件背景** | Delhi HC 针对多起案件，观察到域名注册商（包括 GoDaddy）对侵权域名或诈骗网站存在不履行法院命令的问题 |
| **法院立场** | 如果注册商不遵守法院的封禁命令，将被视为"公共秩序"违规，注册商本身的服务可能被封锁 |
| **GoDaddy 回应** | 在庭上承认进入该案（被 impleaded），承认未完全遵守某些法院命令 |
| **GoDaddy 采取措施** | ⚠️ 出庭应诉，承诺改进合规 |
| **最终结果** | ⚠️ 案件持续进行中；法院明确警告若不遵守命令，注册商可能被禁止在印度运营 |

🔗 **案例链接**：
- https://www.medianama.com/2023/04/223-dnr-public-order-it-ministry-delhi-hc/
- https://www.medianama.com/2023/11/223-delhi-hc-domain-name-registrars-blocking-orders/
- https://lawbeat.in/news-updates/if-wish-operate-india-must-adhere-court-orders-delhi-high-court-tells-domain-name-registrars-scams
- https://www.ndtv.com/india-news/follow-orders-if-you-want-to-do-business-in-india-delhi-hc-to-domain-name-registrars-4603133
- https://telecom.economictimes.indiatimes.com/news/act-against-internet-domain-name-registrars-not-complying-with-court-orders-delhi-hc-to-centre/95456336

---

##### 案例5：Snapdeal vs. GoDaddy（2022年，Delhi High Court）

| 项目 | 内容 |
|------|------|
| **案件背景** | Snapdeal 的商标权案件，寻求禁止注册商注册含 "Snapdeal" 的任何域名 |
| **法院判决** | **拒绝**对 GoDaddy 等注册商发出 blanket injunction |
| **法院理由** | 应对每个具体侵权域名单独申请，而不是预先广泛禁止所有可能包含字样的域名 |
| **GoDaddy 采取措施** | ⚖️ 进行法律抗辩，反对 blanket injunction |
| **最终结果** | ✅ GoDaddy 胜诉；法院认为不能预先禁止所有可能的域名注册，必须逐案处理 |

🔗 **案例链接**：https://www.scconline.com/blog/post/2022/07/18/delhi-high-court-refuses-blanket-injunction-against-godaddy-from-registering-snapdeal-trademark-every-infringement-must-be-petitioned-separately/

---

#### 🇪🇺 欧盟案例

目前公开资料中未发现 GoDaddy 在欧盟作为被告被法院命令封禁网站的重大案例。GoDaddy 在欧盟的运营主要遵循其全球服务条款，并需遵守 GDPR 等欧盟法规。

---

## 第二部分：Cloudflare Registrar 封禁政策与案例

### 2.1 Cloudflare 协议中的封禁规定

#### 2.1.1 Domain Registration Agreement（域名注册协议）

**生效日期**：2025年7月25日

**关键条款（第 4.3 条）：**

> "Cloudflare … reserve[s] the right to deny, cancel, suspend, transfer, redirect, modify, or place … domain name(s) on lock, hold or similar status … to comply with any applicable laws, government rules, regulations or requirements, **court orders**, or requests of law enforcement."

**解读**：Cloudflare 明确保留在法院命令、执法请求等情况下暂停、取消、锁定域名的权利。条款中**未承诺事先通知**。

🔗 **政策链接**：https://www.cloudflare.com/domain-registration-agreement/

---

#### 2.1.2 Registrar Terms of Service（注册商服务条款）

**关键条款：**

> "Cloudflare may deny, cancel, suspend, transfer or modify the Registrar Services or a Registration … to comply with any applicable laws, government rules, regulations or requirements, court orders, or requests of law enforcement."

🔗 **政策链接**：https://www.cloudflare.com/en-gb/registrar-terms/

---

#### 2.1.3 Supplemental Terms（补充条款）

**关键条款：**

> "虽然我们通常尝试在采取行动前给予通知，但在适当的情况下**保留不予通知的权利**。"

**解读**：通知不是强制性的，Cloudflare 保留不通知的权利。

🔗 **政策链接**：https://www.cloudflare-cn.com/supplemental-terms/

---

#### 2.1.4 Registrar FAQ

**关键内容：**

> 域名可能因法律原因（如 UDRP 或法院命令）被"管理员锁定"（administratively locked）而无法删除。

**注意**：FAQ 中并未说明域名所有者一定会被提前通知这一锁定。

🔗 **政策链接**：https://developers.cloudflare.com/registrar/faq/

---

### 2.2 Cloudflare 相关案例

#### 🇺🇸 美国案例

##### 案例1：Grooveshark 商标侵权案（2015年）

| 项目 | 内容 |
|------|------|
| **案件背景** | 音乐版权方（唱片公司）起诉 Grooveshark 克隆网站 |
| **初始法院命令** | 发出秘密禁令（secret injunction），扩大命令范围，要求 Cloudflare 阻断**所有**带 "grooveshark" 名称的域名——不论是否与侵权相关 |
| **Cloudflare 采取措施** | ⚖️ 申请修改命令，争取将责任限于已确定与侵权相关的域名，而非广泛阻断 |
| **EFF 参与** | 电子前沿基金会支持 Cloudflare 反对过于宽泛的命令 |
| **最终结果** | ✅ **Cloudflare 胜诉**；法院同意限缩命令范围，仅针对已确定的侵权域名，而非所有含 "grooveshark" 的域名 |
| **意义** | 确立了互联网服务商不需要充当商标警察的先例 |

🔗 **案例链接**：
- https://www.eff.org/deeplinks/2015/07/victory-cloudflare-against-sopa-court-order-internet-service-doesnt-have-police
- https://blog.cloudflare.com/eff-cloudflare-ask-federal-court-not-to-force-internet-companies-to-enforce-music-labels-trademarks/

---

##### 案例2：Shift4 Payments 案（2025年，加州北区法院）

| 项目 | 内容 |
|------|------|
| **案件背景** | Shift4 Payments 起诉若干域名（如 JaredIsaacmanCourtCase.com 等），寻求初步禁令 |
| **Cloudflare 立场** | 对禁令表示"不反对"（does not intend to oppose） |
| **Cloudflare 采取措施** | ✅ 同意配合执行禁令 |
| **最终结果** | ✅ 法院授予临时禁止令（TRO），要求被告停止使用这些域名；Cloudflare 执行禁令，域名被禁用 |

🔗 **案例链接**：https://law.justia.com/cases/federal/district-courts/california/candce/4%3A2025cv06724/454351/23

---

##### 案例3：Mon Cheri Bridals & Maggie Sottero 案（2021年，北加州联邦地区法院）

| 项目 | 内容 |
|------|------|
| **案件背景** | 两家婚纱设计公司起诉 Cloudflare，指控其为销售仿冒婚纱的网站提供 CDN 服务构成共同侵权 |
| **原告诉求** | 要求 Cloudflare 主动断开对侵权网站的服务 |
| **Cloudflare 采取措施** | ⚖️ 进行法律抗辩，主张其仅提供技术服务，不应承担内容责任 |
| **法院判决** | ✅ **Cloudflare 胜诉**；在 summary judgment 中支持 Cloudflare，判决其不承担共同侵权责任 |
| **最终结果** | ✅ Cloudflare 无需主动切断侵权网站服务，仅在收到有效法律命令时行动 |
| **意义** | 确立 Cloudflare 作为服务提供商的有限责任边界；服务商不需要主动审查内容 |

🔗 **案例链接**：https://arstechnica.com/tech-policy/2021/10/cloudflare-doesnt-have-to-cut-off-copyright-infringing-websites-judge-rules/

---

#### 🇮🇳 印度案例

目前公开资料中未发现 Cloudflare Registrar 在印度作为被告被法院命令封禁域名的重大案例。Cloudflare 在印度的主要法律争议集中在其 CDN/安全服务层面，而非域名注册服务。

---

#### 🇪🇺 欧盟案例

##### 案例1：Guardaserie 案（2024年，意大利罗马法院）

| 项目 | 内容 |
|------|------|
| **案件背景** | 盗版流媒体网站 Guardaserie，提供非法电视剧流媒体 |
| **法院命令** | 要求 Cloudflare **立即停止向 Guardaserie 提供服务**，并**披露客户账户信息** |
| **特殊要求** | 命令适用于现有域名及**未来注册的域名**（防止更换域名躲避封禁） |
| **Cloudflare 采取措施** | ✅ 遵守法院命令，停止服务并披露客户信息 |
| **最终结果** | ✅ Guardaserie 网站被封禁；客户账户信息被披露给权利人 |
| **通知情况** | ❌ 公开资料未显示 Cloudflare 在执行前通知持有人 |

🔗 **案例链接**：https://torrentfreak.com/court-orders-cloudflare-to-block-and-identify-pirate-site-customer-241019/

---

##### 案例2：Universal 音乐版权案（德国高等地区法院）

| 项目 | 内容 |
|------|------|
| **案件背景** | Universal 等音乐版权方要求 Cloudflare 通过公共 DNS 解析器（1.1.1.1）阻止侵权音乐网站 |
| **原告诉求** | 要求 Cloudflare 在 DNS 层面阻断用户访问侵权网站 |
| **Cloudflare 采取措施** | ⚖️ 进行法律抗辩，主张 DNS 解析器不应被强制用于内容阻断 |
| **法院判决** | ✅ **Cloudflare 胜诉**；**拒绝阻断请求** |
| **最终结果** | ✅ 法院认为不能强制全球 DNS 解析器服务商阻断网站 |
| **意义** | 确立了 DNS 解析器服务商的中立性保护；对全球 DNS 服务有重要先例意义 |

🔗 **案例链接**：https://blog.cloudflare.com/latest-copyright-decision-in-germany-rejects-blocking-through-global-dns-resolvers/

---

## 第三部分：Namecheap 封禁政策与案例

### 3.1 Namecheap 协议中的封禁规定

#### 3.1.1 Registration Agreement（域名注册协议）

**关键条款：**

> "You further acknowledge and agree … [that] you may be subject to suspension, cancellation … to comply with applicable law … or pursuant to any legal order or subpoena of any government … or court of competent jurisdiction."

**解读**：Namecheap 保留在收到法院命令等法律程序后，不经持有人同意就暂停、取消域名的权利。

**另一关键条款：**

> "It is **not our responsibility** to forward court orders or other communications to you."

**解读**：明确表示 Namecheap **不负责**将法院命令转发给域名持有人，这是所有主流注册商中**最明确的不通知声明**。

🔗 **政策链接**：https://www.namecheap.com/legal/domains/registration-agreement/

---

#### 3.1.2 Universal Terms of Service（通用服务条款）

**关键条款：**

> "Namecheap may, at any time and in some cases, **without prior notice**, remove any Prohibited Content … and may suspend or terminate access … immediately … In addition … Namecheap will generally issue a prior warning before any suspension, **other than in exceptional cases, or where Namecheap is otherwise legally required to take immediate action**."

**解读**：
- 在"例外情况"或"法律要求立即行动"时，可**无需事先通知**
- 普通违规情况下通常会发出警告
- 法院命令属于"例外情况"

🔗 **政策链接**：https://www.namecheap.com/legal/universal/universal-tos/

---

#### 3.1.3 Court Order & Subpoena Policy（法院命令与传票政策）

**关键条款：**

> 对于**非紧急的美国刑事传票**，Namecheap 表示会"除非情况或传票另有规定，否则会通过电子邮件或美国邮寄方式尽快通知被查信息涉及的客户"。

**重要限制：**
- 仅适用于美国刑事传票
- 紧急情况除外
- 法院命令或传票要求保密时除外
- 民事传票和外国法院命令不在此承诺范围内

**外国法院命令处理：**

> 对非美国法院命令，Namecheap 保留"逐案审查"的权利；如果 Namecheap 不在法院管辖权范围内，可能拒绝遵从。

🔗 **政策链接**：https://www.namecheap.com/legal/general/court-order-and-subpoena-policy/

---

#### 3.1.4 Copyright & Trademark Policies（版权与商标政策）

**关键条款：**

> 在收到版权或商标投诉后，Namecheap 会将投诉内容分享给域名持有人，并收集持有人对投诉的回应。

**解读**：对于普通投诉程序（非法院命令），Namecheap 会通知持有人并给予回应机会。

🔗 **政策链接**：https://www.namecheap.com/legal/general/copyright-trademark-policies/

---

#### 3.1.5 关于通知的总结

| 情形 | 是否通知持有人 |
|------|---------------|
| 美国刑事传票（非紧急） | ✅ 通常会通知 |
| 法院命令（民事/刑事） | ❌ 不保证通知 |
| 外国法院命令 | ❌ 不保证通知，可能拒绝遵从 |
| 紧急/保密法律程序 | ❌ 不会通知 |
| 版权/商标投诉 | ✅ 会通知并给回应机会 |
| 严重违反 TOS | ❌ 可能立即暂停无警告 |

---

### 3.2 Namecheap 相关案例

#### 🇺🇸 美国案例

##### 案例1：域名因法院命令被锁定（用户报告，2025年）

| 项目 | 内容 |
|------|------|
| **案件背景** | 多名用户在 Reddit 报告其域名状态显示 "Locked due to Court Order" |
| **用户发现方式** | 通过账户面板发现，提示联系 legalcompliance@namecheap.com |
| **是否收到通知** | ❌ 多数用户表示**未收到任何提前通知或邮件** |
| **Namecheap 采取措施** | 锁定域名，暂停解析服务 |
| **最终结果** | ⚠️ 结果不一：部分域名长期锁定，部分在用户与 Namecheap 法务沟通后恢复 |

🔗 **案例链接**：https://www.reddit.com/r/NameCheap/comments/1lh4h6o

---

##### 案例2：域名因法律程序被暂停（用户报告）

| 项目 | 内容 |
|------|------|
| **案件背景** | 用户报告域名状态显示 "Domain Suspended due to Legal Proceedings" |
| **是否收到通知** | ❌ 未收到事前通知 |
| **Namecheap 采取措施** | 暂停域名服务 |
| **用户反馈** | 用户需联系 Legal & Compliance 部门了解详情 |

🔗 **案例链接**：https://www.reddit.com/r/NameCheap/comments/1ot5kqf

---

##### 案例3：Infante v. Namecheap Incorporated（2025年，法院案件）

| 项目 | 内容 |
|------|------|
| **案号** | 2:25-cv-02537 (D. Ariz.) |
| **法院** | 美国亚利桑那州联邦地区法院 |
| **法官** | Diane J. Humetewa |
| **案件背景** | 原告 Afonso Infante 在 Namecheap 注册了 6 个域名（vanessarallonza.com 等）。第三方在加州法院获得针对原告的民事骚扰禁令（CHRO），Namecheap 据此暂停了原告的所有 6 个域名 |
| **原告主张** | 原告已对 CHRO 提起上诉，根据加州法律上诉期间禁令应暂停执行，Namecheap 不应维持域名暂停 |
| **原告诉求** | 申请临时限制令（TRO）要求恢复域名，主张 Namecheap 违约 |
| **Namecheap 抗辩** | 引用注册协议中"material allegations of illegal conduct"条款，主张有权在此情况下暂停服务 |
| **法院裁定** | **驳回 TRO 申请**（2025年7月31日） |
| **裁定理由** | 1) 合同条款有效，授权 Namecheap 在收到违法行为指控时暂停服务<br>2) 原告未能证明胜诉可能性<br>3) 原告未能证明不可弥补的损害 |
| **最终结果** | ✅ Namecheap 胜诉，域名维持暂停状态；修正诉状后续也被驳回（with prejudice） |

**案件意义**：
- ✅ 确认了 Namecheap 注册协议中"for cause"暂停条款的法律效力
- ✅ 证明注册商可基于第三方法院命令（如骚扰禁令）采取行动
- ⚠️ 警示域名持有人：即使对原始命令提起上诉，注册商可能仍维持暂停状态

🔗 **案例链接**：
- Justia Docket：https://dockets.justia.com/docket/arizona/azdce/2%3A2025cv02537/1451097
- 判决书：https://www.casemine.com/judgement/us/688db05def417aceda15738d

---

#### 🇮🇳 印度案例

##### 案例1：Delhi High Court 针对 Namecheap 等域名注册商的调查（2023年）

| 项目 | 内容 |
|------|------|
| **案件背景** | Delhi High Court 发现多个域名注册商（包括 Namecheap）未遵守印度法院命令和 IT Rules 2021 的要求 |
| **法院命令** | 要求政府调查并采取措施，禁止不合规的注册商继续在印度提供服务 |
| **法律依据** | 印度《信息技术中介指南规则 2021》（IT Intermediary Guidelines Rules, 2021） |
| **Namecheap 状态** | 被列入未遵守法院命令的注册商名单 |
| **最终结果** | ⚠️ Namecheap 在印度的访问受到影响；部分印度用户报告无法正常访问 Namecheap 服务 |
| **后续发展** | 法院明确指出：若注册商不遵守命令，将被禁止在印度运营 |

🔗 **案例链接**：
- https://telecom.economictimes.indiatimes.com/news/act-against-internet-domain-name-registrars-not-complying-with-court-orders-delhi-hc-to-centre/95456336
- https://theprint.in/india/act-against-internet-domain-name-registrars-not-complying-with-court-orders-delhi-hc-to-centre/1211113/

---

##### 案例2：Namecheap 在印度被 ISP 层面封锁

| 项目 | 内容 |
|------|------|
| **案件背景** | 由于 Namecheap 未遵守印度法院命令和 IT 规则，被印度政府/ISP 封锁访问 |
| **封锁方式** | ISP 层面的 DNS 封锁 |
| **影响范围** | 印度境内用户无法正常访问 Namecheap 网站和服务 |
| **是否通知客户** | ❌ 公开资料未显示 Namecheap 向印度客户发出事前通知 |
| **最终结果** | ⚠️ 封锁持续中；用户需使用 VPN 等方式访问 |

🔗 **案例链接**：https://en.wikipedia.org/wiki/Namecheap

---

#### 🇪🇺 欧盟案例

目前公开资料中未发现 Namecheap 在欧盟作为被告被法院命令封禁特定域名的重大案例。Namecheap 在欧盟的运营需遵守 GDPR 等法规，但未见因法院命令封禁域名的公开判决。

---

## 第四部分：总结与对比

### 4.1 政策对比表

| 对比项目 | GoDaddy | Cloudflare Registrar | Namecheap |
|---------|---------|---------------------|-----------|
| **法院命令执行权** | ✅ 明确保留 | ✅ 明确保留 | ✅ 明确保留 |
| **"without notice" 条款** | ✅ 明确写明 | ⚠️ "保留不予通知的权利" | ✅ 明确写明"不负责转发法院命令" |
| **10天通知条款** | ❌ 域名服务未发现 | ❌ 未发现 | ❌ 未发现 |
| **对宽泛禁令的态度** | 较少公开反对 | 曾积极反对（Grooveshark案） | 未见公开反对案例 |
| **印度法院案例** | 🔴 多个明确案例 | 🟢 较少公开案例 | 🔴 被列入不合规名单，服务被封锁 |
| **美国法院案例** | 🟡 有（Chanel、JotForm等） | 🟡 有（Grooveshark、Shift4等） | 🟡 有用户报告，无重大公开案例 |
| **欧盟法院案例** | 🟢 较少公开案例 | 🟡 有（Guardaserie、Universal等） | 🟢 较少公开案例 |
| **外国法院命令处理** | 遵守有管辖权法院命令 | 遵守有管辖权法院命令 | 逐案审查，可能拒绝非美国命令 |

---

### 4.2 封禁类型对比

| 封禁类型 | GoDaddy | Cloudflare | Namecheap |
|---------|---------|------------|-----------|
| **域名转移/没收** | ✅ Chanel案 | - | - |
| **域名暂停/锁定** | ✅ 印度多案 | ✅ Guardaserie案 | ✅ 用户报告多案 |
| **DNS 去索引化** | ✅ Chanel案 | - | - |
| **身份信息披露** | ✅ Tamaris案 | ✅ Guardaserie案 | ⚠️ 按传票政策执行 |
| **通知义务（向权利人）** | ✅ Swiggy案 | - | - |
| **服务终止** | ✅ JotForm事件 | ✅ Guardaserie案 | ✅ 用户报告 |
| **注册商本身被封锁** | - | - | ✅ 印度案例 |

---

### 4.3 通知政策对比

| 情形 | GoDaddy | Cloudflare | Namecheap |
|------|---------|------------|-----------|
| **紧急法院命令/禁令** | ❌ 不保证通知 | ❌ 不保证通知 | ❌ 不保证通知 |
| **执法机关请求** | ❌ 可直接执行 | ❌ 可直接执行 | ❌ 可直接执行 |
| **美国刑事传票（非紧急）** | ❌ 无明确承诺 | ❌ 无明确承诺 | ✅ 通常会通知 |
| **民事法院命令** | ❌ 无明确承诺 | ❌ 无明确承诺 | ❌ 不保证通知 |
| **外国法院命令** | ⚠️ 遵守有管辖权命令 | ⚠️ 遵守有管辖权命令 | ⚠️ 逐案审查，可能拒绝 |
| **常规服务断开** | ❌ 无明确承诺 | ❌ 无明确承诺 | ⚠️ 一般会警告，例外除外 |
| **DMCA/商标投诉** | ✅ 通常会通知 | ✅ 通常会通知 | ✅ 会通知并给回应机会 |
| **UDRP 域名争议** | ✅ 会通知 | ✅ 会通知 | ✅ 会通知 |
| **转发法院命令给持有人** | ❌ 无承诺 | ❌ 无承诺 | ❌ **明确表示不负责** |

---

### 4.4 ICANN 相关规定

#### 4.4.1 Registrar Accreditation Agreement (RAA)

ICANN 的注册商认证协议要求注册商在以下情况**必须通知**注册人：

| 情形 | 是否要求通知 |
|------|-------------|
| 域名即将到期 | ✅ 必须通知 |
| 自动续费 | ✅ 必须通知 |
| UDRP 域名争议程序 | ✅ 必须通知被投诉方 |
| 注册信息变更 | ✅ 必须通知 |
| 删除政策变更 | ✅ 必须通知 |

**但不包括：**
- ❌ 法院命令导致的封禁
- ❌ 执法机关请求
- ❌ 紧急法律程序

🔗 **ICANN 注册人权利与责任**：https://www.icann.org/EN/REGISTRARS/REGISTRANT-RIGHTS-RESPONSIBILITIES-EN.HTM

---

#### 4.4.2 Uniform Domain Name Dispute Resolution Policy (UDRP)

根据 UDRP 政策：

- 注册商**必须**将投诉/争议通知域名持有人
- 持有人有权回应和申诉
- 纠纷决定后通常有**等待期**，允许持有人通过法院采取进一步措施

🔗 **UDRP 政策**：https://www.icann.org/en/contracted-parties/consensus-policies/uniform-domain-name-dispute-resolution-policy/uniform-domain-name-dispute-resolution-policy-25-02-2012-en

---

#### 4.4.3 ICANN 未规定的情形

ICANN 政策中**未明确要求**注册商在以下情况通知注册人：

1. 法院命令（court orders）导致的域名封禁
2. 执法机关（law enforcement）请求
3. 紧急/保密法律程序
4. Ex-parte（单方面）禁令

这意味着**注册商在法院命令下封禁域名前是否通知，完全取决于注册商自身政策**，而非 ICANN 强制要求。

---

### 4.5 关键结论

1. **三家注册商均不保证法院命令前通知**
   - GoDaddy 明确写有 "without prior notice"
   - Cloudflare 写有 "保留不予通知的权利"
   - Namecheap **最明确**：写有 "不负责转发法院命令给持有人"

2. **印度法律风险最高**
   - GoDaddy：多个明确的法院命令案例
   - Namecheap：被列入不合规名单，服务在印度被封锁
   - 法院曾警告不遵守将禁止注册商在印度运营

3. **Cloudflare 更积极反对宽泛禁令**
   - Grooveshark 案中成功限缩法院命令范围
   - Universal 德国案中胜诉，保护 DNS 解析器中立性
   - 获得 EFF 支持

4. **Namecheap 对外国法院命令态度最保守**
   - 明确表示逐案审查非美国法院命令
   - 可能拒绝遵从不在其管辖权范围内的命令
   - 但这也导致其在印度被封锁

5. **ICANN 未填补法院命令通知的空白**
   - 仅要求 UDRP 等争议程序中通知
   - 法院命令情形下无强制通知要求

6. **域名持有人的保护有限**
   - Ex-parte 禁令下可能毫无预警被封禁
   - 需依赖法院程序本身的通知要求（如有）
   - 建议保持 WHOIS 信息准确，定期监控域名状态

---

### 4.6 风险评估

| 风险因素 | GoDaddy | Cloudflare | Namecheap |
|---------|---------|------------|-----------|
| **印度法律风险** | 🔴 高 — 多个案例 | 🟡 中 — 案例较少 | 🔴 高 — 服务已被封锁 |
| **美国法律风险** | 🟡 中 — 主要是商标案 | 🟡 中 — 有胜诉先例 | 🟡 中 — 用户报告 |
| **欧盟法律风险** | 🟢 低 — 案例较少 | 🟡 中 — 有封禁案例 | 🟢 低 — 案例较少 |
| **无预警封禁风险** | 🔴 高 — 政策明确 | 🔴 高 — 政策明确 | 🔴 高 — 政策最明确 |
| **宽泛禁令风险** | 🟡 中 | 🟢 低 — 有反对先例 | 🟡 中 |
| **外国命令拒绝风险** | 🟢 低 — 通常遵守 | 🟢 低 — 通常遵守 | 🟡 中 — 可能拒绝 |
| **注册商本身被封锁风险** | 🟢 低 | 🟢 低 | 🔴 高 — 印度已发生 |

---

## 附录：政策链接汇总

### GoDaddy

| 文档 | 链接 |
|------|------|
| Universal Terms of Service | https://registry.godaddy/legal/ |
| Complaint Mechanisms | https://help-center.dc-aws.godaddy.com/help/godaddy-complaint-mechanisms-40875 |
| GCD Terms of Use | https://gcd.com/terms-of-use/ |
| Registration Agreement | https://www.godaddy.com/legal/agreements/domain-name-registration-agreement |
| Trademark/Copyright Policy | https://www.godaddy.com/en/legal/agreements/trademark-copyright-infringement |

### Cloudflare

| 文档 | 链接 |
|------|------|
| Domain Registration Agreement | https://www.cloudflare.com/domain-registration-agreement/ |
| Registrar Terms of Service | https://www.cloudflare.com/en-gb/registrar-terms/ |
| Supplemental Terms | https://www.cloudflare-cn.com/supplemental-terms/ |
| Registrar FAQ | https://developers.cloudflare.com/registrar/faq/ |

### Namecheap

| 文档 | 链接 |
|------|------|
| Registration Agreement | https://www.namecheap.com/legal/domains/registration-agreement/ |
| Universal Terms of Service | https://www.namecheap.com/legal/universal/universal-tos/ |
| Court Order & Subpoena Policy | https://www.namecheap.com/legal/general/court-order-and-subpoena-policy/ |
| Copyright & Trademark Policies | https://www.namecheap.com/legal/general/copyright-trademark-policies/ |
| Why Domain Suspended (FAQ) | https://www.namecheap.com/support/knowledgebase/article.aspx/10626/46/why-has-my-domain-been-suspended/ |

### ICANN

| 文档 | 链接 |
|------|------|
| Registrant Rights & Responsibilities | https://www.icann.org/EN/REGISTRARS/REGISTRANT-RIGHTS-RESPONSIBILITIES-EN.HTM |
| UDRP Policy | https://www.icann.org/en/contracted-parties/consensus-policies/uniform-domain-name-dispute-resolution-policy/uniform-domain-name-dispute-resolution-policy-25-02-2012-en |

---

## 深度研究：印度法院 Dynamic / Dynamic+ Injunction 框架

### 一、什么是 Dynamic Injunction

**Dynamic Injunction（动态禁令）** 是印度法院为应对网络盗版和商标侵权中"九头蛇式"（hydra-headed）侵权行为而发展的法律机制——即一个侵权网站被封锁后，很快通过镜像站、重定向、不同域名或字母数字编码变体重新上线。

**核心特点**：
- 法院禁令不仅覆盖已知的侵权域名/网站
- 还涵盖未来发现的**镜像网站、重定向、域名变体**等具有实质相同内容的新实体
- 权利人可通过法院指定的 Joint Registrar 程序将新实体加入原有禁令，**无需每次重新起诉**

**首创案例**：UTV Software Communications Ltd. v. 1337x.to（2019年4月）
- 来源：https://itif.org/publications/2019/05/29/india-and-website-blocking-courts-allow-dynamic-injunctions-fight-digital/

---

### 二、Dynamic+ Injunction 的升级

**Dynamic+ Injunction** 是在 Dynamic Injunction 基础上的"加号扩展"：

| 功能对比 | Dynamic Injunction | Dynamic+ Injunction |
|----------|-------------------|---------------------|
| 覆盖已知侵权域名 | ✔ | ✔ |
| 覆盖镜像/重定向/变体域名 | ✔ | ✔ |
| 覆盖**未来创作的内容** | ❌ | ✔ |
| 权利人可**直接通知**中介采取行动 | ❌ | ✔ |
| 无需每次法院审批 | 部分 | ✔ |

**Superlative Injunction（超级禁令）**：更进一步的形式，法院赋予权利人在获得初步禁令后，几乎可以**实时自动执行**对新侵权域名的封锁。

来源：https://www.managingip.com/article/2f71ano5zuw2pqzcncv7k/sponsored-content/from-dynamic-to-superlative-indian-courts-adapt-injunctive-relief-to-digital-infringement

---

### 三、法律依据

Dynamic / Dynamic+ Injunction 的法律基础包括：

1. **《版权法》（Copyright Act 1957）**：版权临时救济条款
2. **《信息技术法》（Information Technology Act 2000）**：中介责任规定
3. **《中介指南与数字媒体伦理规则》（IT Rules, 2021）**：中介义务增强
4. **《民事诉讼法典》（CPC）Order XXXIX**：临时禁令程序
5. **Order I Rule 10**：追加新被告（用于镜像/变体域名）

---

### 四、重大案例汇总（2019-2025）

| 案例 | 时间 | 原告 | 涉及注册商 | 法院命令内容 |
|------|------|------|-----------|-------------|
| **UTV Software v. 1337x.to** | 2019年4月 | UTV Software | 多个 | 首创 Dynamic Injunction，允许将镜像域名纳入禁令 |
| **Reliance v. Anonymous Sellers** | 2025年7月10日 | Reliance Industries | 电商平台 | 针对匿名卖家的 Dynamic Injunction，授权直接通知平台下架 |
| **JioStar India v. criclk.com 等** | 2025年7月 | JioStar India | **Namecheap Inc.**, Tucows, Sav.com 等 | Ex parte Dynamic+ 禁令；**72小时内锁定域名**；提供注册人信息；允许实时封锁新镜像 |
| **DAZN v. 盗版网站（FIFA Club World Cup 2025）** | 2025年 | DAZN | **Namecheap Inc.** 等 | Dynamic+ 禁令，封锁非法直播网站 |
| **Tata v. John Doe** | 2025年 | Tata Sons | 多个 | "Trigger words" 机制，授权原告直接通知注册商锁定含特定关键词的域名 |
| **Warner Bros., Netflix, Disney 等** | 2025年12月18日 | 多家流媒体公司 | DNRs（含 Namecheap）, ISP, MeitY, DoT | Dynamic+ 禁令；**72小时内锁定/暂停域名**；**4周内提交注册人信息** |

**关键来源**：
- JioStar 案：https://www.scconline.com/blog/post/2025/07/02/delhi-high-court-dynamic-injunction-jiostar-india-england-2025-streaming-legal-news/
- Warner Bros./Netflix 案：https://www.medianama.com/2026/01/223-delhi-hc-dynamic-injunction-piracy-sites-illegally-streaming-netflix-warner-bros-content/
- DAZN 案：https://24law.in/story/delhi-high-court-grants-dynamic-plus-ex-parte-injunction-to-dazn-blocks-websites-illegally-streaming

---

### 五、域名注册商的义务

在 Dynamic+ Injunction 框架下，域名注册商（DNRs）被要求承担以下义务：

| 义务类型 | 具体要求 | 时限 |
|---------|---------|------|
| **域名锁定/暂停** | 停止解析、锁定或暂停被法院认定的侵权域名 | **72小时内** |
| **注册人信息披露** | 提交域名注册人的身份、联系方式、付款信息等 | **4周内** |
| **e-KYC 实名注册** | 对新注册实施实名认证 | 持续要求 |
| **禁止默认隐私保护** | 除非用户主动请求，否则不得遮蔽注册人信息 | 持续要求 |
| **配合未来禁令** | 对新识别的镜像/变体域名自动执行封锁 | 按通知执行 |

**不合规后果**：
- Delhi High Court 已要求 MeitY/DoT 审查不合规注册商是否应被允许在印度继续提供服务
- 来源：https://www.ndtv.com/india-news/take-action-against-internet-domain-name-registrars-for-violation-delhi-high-court-3511464

---

### 六、Safe Harbour 地位的削弱

法院在多个案件中明确：注册商若提供以下"增值服务"，可能**丧失中介豁免权**：

- 域名建议/推荐服务
- 替代域名拍卖
- 代理注册（Proxy Registration）隐藏真实身份
- 域名交易平台

**典型案例**：Dabur India Ltd. v. Ashok Kumar & Ors.
- 法院指出：注册商若"knowingly or negligently"使侵权行为发生，不能再享有 Safe Harbour 保护
- 来源：https://chandrawatpartners.co/dnrs-to-lose-safe-harbour-for-trademark-abuse-delhi-high-court-issues-sweeping-directions-to-curb-online-fraud/

---

### 七、跨境执行的挑战

尽管 Dynamic+ 禁令在纸面上要求**全球范围内**锁定域名，但实际执行面临挑战：

| 挑战 | 说明 |
|------|------|
| **管辖权争议** | 国际注册商可能质疑印度法院的域外管辖权 |
| **隐私保护服务** | Privacy/Proxy 服务可能隐藏真实注册人 |
| **执行不一致** | 部分国际注册商未完全遵守全球域名暂停要求 |
| **技术边界** | 注册商能做"注册状态暂停"，但"访问封锁"通常是 ISP 职权 |

来源：https://techenclave.com/t/disney-netflix-crunchyroll-push-global-pirate-site-takedowns-via-indian-court/411904

---

### 八、对 Namecheap 的具体影响

**确认：Namecheap 被明确列为被告的案件**：

1. **JioStar India v. criclk.com 等案（2025年7月）**
   - Namecheap Inc. 作为域名注册商被告
   - 被命令在 72 小时内锁定/暂停域名
   - 被要求提供注册人信息

2. **DAZN v. 盗版网站案（FIFA Club World Cup 2025）**
   - Namecheap Inc. 被指定为被告之一

3. **Warner Bros., Netflix, Disney 案（2025年12月）**
   - DNRs（包括 Namecheap）被纳入命令框架

**当前状态**：Namecheap 网站访问已基本恢复，但在新的 Dynamic+ 案件中持续被要求配合执行域名锁定和信息披露义务。

---

## 深度研究：Infante v. Namecheap 案（美国）

### 一、案件基本信息

| 项目 | 内容 |
|------|------|
| **案件名称** | Infante v. Namecheap Incorporated |
| **案号** | 2:25-cv-02537 (D. Ariz.) |
| **法院** | 美国亚利桑那州联邦地区法院 |
| **法官** | Diane J. Humetewa |
| **提起日期** | 2025年7月21日 |
| **案件性质** | 合同纠纷（Contract Dispute）+ 声明性判决请求 |

**案件链接**：
- Justia Docket：https://dockets.justia.com/docket/arizona/azdce/2%3A2025cv02537/1451097
- CaseMine：https://www.casemine.com/judgement/us/688db05def417aceda15738d

---

### 二、案件背景

**原告**：Afonso Infante（居住于内华达州拉斯维加斯）

**涉案域名**（6个）：
- vanessarallonza.com
- vanessa-rallonza.com
- vanessarallonza.net
- vanessa-rallonza.net
- vanessarallonza.org
- vanessa-rallonza.org

**事件起因**：
1. 原告在 Namecheap 注册了上述 6 个域名
2. 第三方在加州法院获得针对原告的 **Civil Harassment Restraining Order（CHRO，民事骚扰禁令）**
3. Namecheap 基于该禁令**暂停了原告的所有 6 个域名**
4. 原告声称其已对 CHRO 提起上诉，根据 **California Code of Civil Procedure § 916(a)**，上诉期间禁令应自动暂停执行（stay）
5. 原告认为 Namecheap 在禁令被暂停期间仍维持域名暂停是错误的

---

### 三、原告的诉讼请求

1. **恢复域名**：要求 Namecheap 立即恢复 6 个被暂停域名的使用权
2. **违约索赔**：声称 Namecheap 违反注册协议
3. **其他主张**：转换（Conversion）、不正当竞争、干涉契约义务、违反诚实信用义务等
4. **临时限制令（TRO）**：请求法院在诉讼期间阻止 Namecheap 进一步干预域名

---

### 四、Namecheap 的抗辩（反对 TRO 动议）

**提交时间**：2025年7月29日

**核心抗辩理由**：

| 抗辩点 | 内容 |
|--------|------|
| **合同条款授权** | 注册协议明确规定：当存在 **"material allegations of illegal conduct"（违法行为的实质性指控）** 时，Namecheap 有权暂停或终止服务 |
| **暂停行为合法** | 加州的骚扰禁令构成"违法行为指控"，Namecheap 的暂停行为符合合同约定 |
| **TRO 要件不满足** | 原告未能证明：<br>① 胜诉可能性（likelihood of success）<br>② 不可弥补的损害（irreparable harm）<br>③ 利益平衡有利于原告 |

**支持材料**：Namecheap 提交了 Hillan Klein 的声明（Declaration）支持其立场

---

### 五、法院裁定

**裁定日期**：2025年7月31日

**裁定结果**：**驳回原告的 TRO 申请**

**主要理由**：

1. **合同条款有效**
   - 法院审查了 Namecheap 的注册协议
   - 确认协议中"for cause"终止条款有效
   - 该条款允许 Namecheap 在收到"违法行为实质性指控"时暂停服务

2. **胜诉可能性不足**
   - 原告在违约诉讼中不太可能胜诉
   - Namecheap 的行为符合合同约定

3. **其他主张被驳回**
   - 转换（Conversion）：域名不是"有形财产"，不适用转换诉讼
   - 不正当竞争等：缺乏足够事实支持

4. **后续处理**
   - 取消原定于 2025年8月1日的 TRO 听证会
   - 允许原告提交修正诉状（First Amended Complaint）
   - 修正诉状后续也被驳回（with prejudice，不得再次提交）

---

### 六、案件意义

**对 Namecheap 的意义**：
- 确认了 Namecheap 注册协议中"for cause"暂停条款的有效性
- 证明注册商可以基于第三方法院命令（如骚扰禁令）采取行动
- 展示了 Namecheap 愿意通过法律程序维护其政策

**对域名持有人的警示**：
- 注册协议中的暂停条款具有法律效力
- 第三方法院命令可能导致域名被暂停
- 即使对原始命令提起上诉，注册商可能仍维持暂停状态
- 恢复域名可能需要直接与注册商协商或通过诉讼

**与印度案件的区别**：

| 对比项 | Infante v. Namecheap（美国） | 印度 Dynamic+ Injunction |
|--------|------------------------------|--------------------------|
| 案件性质 | 合同纠纷（域名持有人 vs 注册商） | 版权/商标侵权（权利人 vs 侵权网站） |
| 暂停依据 | 第三方骚扰禁令 + 合同条款 | 法院动态禁令 |
| Namecheap 角色 | 被告（被起诉） | 被告/被命令方（被要求配合） |
| 法院态度 | 支持 Namecheap 的暂停权 | 要求注册商配合执行禁令 |
| 结果 | Namecheap 胜诉，域名维持暂停 | 注册商需锁定侵权域名 |

---

## 深度研究：印度域名封锁风险分析——为什么风险最大

### 一、法律框架与制度基础

印度拥有全球最完善且最激进的域名封锁法律工具体系：

#### 1.1 核心法律条款

| 法律 | 条款 | 内容 | 与域名封锁的关系 | 来源类型 | 来源链接 |
|------|------|------|-----------------|----------|----------|
| **IT Act 2000** | **Section 69A** | 授权中央政府以国家安全、公共秩序、外交关系等理由封锁任何网络信息 | 法院/政府可依此封锁域名；不合规注册商可被视为"违反公共秩序"而被整体封禁 | 📜 官方法条 | https://www.itlaw.in/section-69a-power-to-issue-directions-for-blocking-for-public-access-of-any-information-through-any-computer-resource/ |
| **IT Act 2000** | **Section 79** | 中介方（含注册商）的安全港保护条款 | 若注册商未履行 due diligence 或助长侵权，可丧失安全港保护 | ⚖️ 律所文章 | https://www.barandbench.com/columns/safe-harbour-exemptions-available-to-intermediaries-exception-or-norm-under-digital-india-act |
| **IT Act 2000** | **Section 79(3)(b)** | 中介方未遵从法院/政府 takedown 命令时失去豁免 | 注册商必须执行法院禁令，否则承担连带责任 | 📚 判决分析 | https://indiankanoon.org/doc/47479491/ (UTV 案判决书) |
| **IT Rules 2021** | 中介指南规则 | 要求中介方设立 Grievance Officer、遵守法院命令、配合信息披露 | 注册商不合规可被"禁止在印度提供服务" | ⚖️ 律所文章 | https://www.mondaq.com/india/privacy-protection/1075410/redefining-intermediary-safe-harbour-free-speech-and-privacy-concerns-in-india |
| **Copyright Act 1957** | Section 51(a), 14(d), 17 等 | 保护复制权、传播权、公开表演权等 | 版权侵权案件中动态禁令的法律基础 | 📚 判决书 | https://indiankanoon.org/doc/156457058/ (Universal Studios 案) |
| **Trade Marks Act 1999** | Passing off 原则 | 保护商标，禁止混淆性使用 | 域名被视为商标，适用商标法保护 | 📚 最高法院判决 | https://indiankanoon.org/doc/1587012/ (Satyam Infoway v. Sifynet) |
| **CPC 1908** | **Order I Rule 10** | 允许追加当事人 | 用于将镜像/变体域名加入原有禁令，无需重新起诉 | ⚖️ 律所文章 | https://www.algindia.com/are-dynamic-injunctions-permissible-under-section-151-cpc/ |
| **CPC 1908** | **Section 151** | 法院固有权力 | 授权法院发布动态禁令等创新救济 | ⚖️ 律所文章 | https://www.lakshmisri.com/insights/articles/dynamic-injunction-against-rogue-websites-in-utv-case-balanced-remedy-or-excessive-enforcement |

#### 1.2 封锁程序规范

**IT (Procedure and Safeguards for Blocking of Access) Rules, 2009**：
- 规定封锁程序的具体要求
- 包括 designated officer 审查、听证要求、理由记录等

🔗 来源（律所文章）：https://www.mondaq.com/india/it-and-internet/1475400/website-ip-address-blocking-under-the-indian-it-rules-law-in-india
🔗 来源（法律研究）：https://cis-india.org/internet-governance/blog/the-legal-validity-of-internet-bans-part-ii

---

### 二、印度执法风格的六大特征

#### 特征 1：Ex Parte 禁令常态化

| 对比 | 美国 | 印度 |
|------|------|------|
| Ex parte TRO | 例外情况，需证明紧急性 | **常态化**，版权/商标案普遍使用 |
| 被告知情权 | 通常会通知被告 | 经常在被告不知情时发布禁令 |
| 抗辩机会 | 禁令发布后可快速申请撤销 | 撤销程序复杂，域名可能已被锁定数月 |

**案例依据**：Reliance Industries v. Anonymous Sellers (2025) - Ex parte ad-interim 动态++ 禁令
🔗 https://www.mondaq.com/india/trademark/1662760/the-evolving-pace-of-dynamic-injunctions-in-the-digital-age

---

#### 特征 2：动态禁令自动扩展

法院允许禁令自动扩展至：
- ✅ 原域名的镜像站（Mirror）
- ✅ 重定向域名（Redirect）
- ✅ 字母/数字变体（Alphanumeric variants）
- ✅ **未来创作的内容**（Dynamic+ 特有）
- ✅ **未来注册的域名**（预防性禁止）

**首创案例**：UTV Software Communications Ltd. v. 1337x.to (2019)
- 案号：CS(COMM) 724/2017, Delhi High Court
- 首次确立"hydra-headed"（九头蛇）侵权行为的动态应对机制
- 通过 Order I Rule 10 CPC 实现禁令自动扩展
- 确立"rogue website / FIOL"的判定标准

🔗 **官方判决书**：https://indiankanoon.org/doc/47479491/
🔗 **CaseMine 判决**：https://www.casemine.com/judgement/in/5caf6c229eff430a7aaa7b87
🔗 **律所分析（Lakshmikumaran & Sridharan）**：https://www.lakshmisri.com/insights/articles/dynamic-injunction-against-rogue-websites-in-utv-case-balanced-remedy-or-excessive-enforcement
🔗 **SFLC.in 案例分析**：https://sflc.in/policies-and-cases/utv-software-communication-ltd-ors-v-1337x-to-ors-dynamic-injunctions-for-website-blocking-case/

---

#### 特征 3：72小时强制响应期限

| 义务 | 时限 | 不合规后果 |
|------|------|-----------|
| 域名锁定/暂停 | **72小时** | 可能被追究藐视法庭 |
| 注册人信息披露 | **4周** | 可能被禁止在印度运营 |
| ISP 访问封锁 | **立即** | 行政处罚 |

**案例依据**：Warner Bros./Netflix/Disney v. 47 Pirate Sites (2025年12月)
🔗 https://www.medianama.com/2026/01/223-delhi-hc-dynamic-injunction-piracy-sites-illegally-streaming-netflix-warner-bros-content/

---

#### 特征 4：域外管辖的强硬态度

印度法院的立场：
> "如果你想在印度市场提供服务，就必须遵守印度法院的命令——无论你的公司注册在哪里。"

**具体表现**：
- 要求美国注册商（Namecheap、Dynadot、Tucows）在**全球范围内**锁定域名
- 要求提供域名注册人的**完整个人信息**，无视 GDPR 等数据保护法
- 不接受"无印度实体"的管辖权抗辩

**案例依据**：Star India v. MHDTV.World (2022) - 5家境外注册商被点名
🔗 https://www.ndtv.com/india-news/take-action-against-internet-domain-name-registrars-for-violation-delhi-high-court-3511464

---

#### 特征 5：整体服务封禁先例

**2023年3月事件**：
- Namecheap、Dynadot、Tucows、Gransy、Sarek 等注册商
- 因不遵守法院命令，被印度 ISP **整体封锁**
- 不是封锁个别域名，而是封锁**注册商官网本身**
- 影响所有使用这些注册商的用户（无论是否涉及侵权）

**这在美国和欧盟从未发生过。**

🔗 https://www.medianama.com/2023/03/223-namecheap-domain-registrars-blocked-india-3/

---

#### 特征 6：Safe Harbor 保护的瓦解

**美国**：注册商作为"中立管道"，享有 DMCA Safe Harbor 保护

**印度**：法院在多个案件中明确表示，注册商若提供以下"增值服务"，将**丧失 Section 79 安全港保护**：

| 增值服务 | 法院态度 |
|---------|---------|
| 域名建议/推荐 | ❌ 可能被视为助长侵权 |
| 替代域名拍卖 | ❌ 丧失中立地位 |
| 隐私/代理注册 | ❌ 帮助隐藏侵权者身份 |
| 算法推荐 | ❌ 主动参与侵权行为 |

**关键案例**：Snapdeal vs GoDaddy (2022)
- GoDaddy 提供含 "SNAPDEAL" 商标的替代域名建议
- 法院认定此行为侵犯商标，不能享受安全港保护

🔗 **官方判决书**：https://indiankanoon.org/doc/11734158/
🔗 **律所分析**：https://www.latestlaws.com/judgements/delhi-hc/2022/april/2022-latest-caselaw-1071-del/

**Dabur India Ltd. v. Ashok Kumar 案**：
> "如果注册商 knowingly or negligently 使侵权行为发生，不能享有 Safe Harbour 保护。"

🔗 **律所分析（Chandrawat & Partners）**：https://chandrawatpartners.co/dnrs-to-lose-safe-harbour-for-trademark-abuse-delhi-high-court-issues-sweeping-directions-to-curb-online-fraud/

---

### 三、关键判例汇总表

| 案例 | 时间 | 核心争点 | 法院命令 | 意义 | 链接 |
|------|------|---------|---------|------|------|
| **Satyam Infoway v. Sifynet** | 2004 | 域名是否受商标法保护 | 域名可被视为商标，适用 passing off 原则 | 确立域名的商标法地位 | https://en.wikipedia.org/wiki/Satyam_Infoway_Ltd._v._Sifynet_Solutions_Pvt._Ltd. |
| **Shreya Singhal v. Union of India** | 2015 | Section 69A 合宪性；Section 66A 合宪性 | Section 69A 合宪；Section 66A 违宪 | 确立网站封锁的宪法框架 | https://en.wikipedia.org/wiki/Shreya_Singhal_v._Union_of_India |
| **UTV v. 1337x.to** | 2019 | 是否允许动态禁令 | 首次授予 Dynamic Injunction | 开创动态禁令先例 | https://www.medianama.com/2019/04/223-delhi-high-court-issues-indias-first-dynamic-website-blocking-injunction-for-copyright-infringement-divij-joshi-2/ |
| **Snapdeal v. GoDaddy** | 2022 | 注册商提供侵权域名建议是否失去安全港 | DNR 不能以"自动系统"为由逃避责任 | 削弱注册商安全港保护 | https://www.latestlaws.com/judgements/delhi-hc/2022/april/2022-latest-caselaw-1071-del/ |
| **Star India v. MHDTV.World** | 2022 | 境外注册商不合规 | 要求政府对 5 家注册商采取行动 | 首次整体封禁注册商 | https://www.ndtv.com/india-news/take-action-against-internet-domain-name-registrars-for-violation-delhi-high-court-3511464 |
| **Universal City Studios v. Dotmovies** | 2023 | 版权侵权网站封锁 | Dynamic+ 禁令，覆盖未来作品 | 扩展至未来内容保护 | https://www.legitquest.com/case/universal-city-studios-llc-and-ors-v-dotmoviesbaby-and-ors/78504B |
| **Reliance v. Anonymous Sellers** | 2025.7 | 电商平台假冒商品 | Dynamic++ 禁令，权利人可直接通知平台下架 | 进一步简化执行程序 | https://www.mondaq.com/india/trademark/1662760/the-evolving-pace-of-dynamic-injunctions-in-the-digital-age |
| **JioStar v. criclk.com** | 2025.7 | 体育赛事直播盗版 | Ex parte Dynamic+ 禁令，72小时锁定 | Namecheap 被明确列为被告 | https://www.scconline.com/blog/post/2025/07/02/delhi-high-court-dynamic-injunction-jiostar-india-england-2025-streaming-legal-news/ |
| **Galaxy Health 案 (Madras HC)** | 2025 | 预防性域名注册禁止 | 禁止注册含特定字串的域名 | 扩展至**未来域名注册** | https://spicyip.com/2025/08/domain-name-ring-fencing-evaluation-of-madras-hcs-new-pre-emptive-twist-to-dynamic-injunctions.html |
| **Warner Bros./Netflix/Disney** | 2025.12 | 47个盗版网站 | Dynamic+ 禁令，全面配合要求 | 最新大规模动态禁令 | https://www.medianama.com/2026/01/223-delhi-hc-dynamic-injunction-piracy-sites-illegally-streaming-netflix-warner-bros-content/ |
| **DAZN v. Buffsports.me** | 2025 | FIFA 直播盗版 | Superlative Injunction（超级禁令） | 实时封锁新域名 | https://www.managingip.com/article/2f71ano5zuw2pqzcncv7k/sponsored-content/from-dynamic-to-superlative-indian-courts-adapt-injunctive-relief-to-digital-infringement |

---

### 四、风险等级对比

| 风险维度 | 🇺🇸 美国 | 🇪🇺 欧盟 | 🇮🇳 印度 |
|---------|---------|---------|---------|
| **禁令类型** | 逐案、针对特定域名 | 逐案，有比例原则 | Dynamic/+/++，自动扩展 |
| **响应时限** | 无强制时限 | 合理时间 | **72小时** |
| **域外效力** | 仅限美国境内 | 仅限欧盟境内 | **要求全球执行** |
| **注册商角色** | 中立中介 | 中介责任有限 | **被视为执法参与者** |
| **Safe Harbor** | 强保护 | 较强保护 | **几乎无效** |
| **不合规后果** | 藐视法庭（个案） | 罚款（个案） | **整体服务被封禁** |
| **正当程序** | 完整，可抗辩 | 较完整 | **薄弱，ex parte 常态化** |
| **预防性禁令** | 罕见 | 罕见 | **常见，可禁止未来注册** |

---

### 五、风险金字塔

```
                        ▲
                       /█\           🇮🇳 印度 - 极高风险
                      /███\          - 整体服务可能被封禁
                     /█████\         - 域外管辖，全球执行
                    /███████\        - 72小时强制响应
                   /█████████\       - Safe Harbor 几乎无效
                  /███████████\      - 预防性禁令常见
                 ─────────────────
                /█████████████████\    🇮🇹 意大利 - 高风险
               /███████████████████\   - Piracy Shield 实时封锁
              /█████████████████████\  - 但仅限 ISP 层面
             ─────────────────────────
            /█████████████████████████\   🇪🇺 其他欧盟 - 中等风险
           /███████████████████████████\  - 有比例原则
          /█████████████████████████████\ - DSA 框架下责任增加
         ───────────────────────────────────
        /█████████████████████████████████████\  🇺🇸 美国 - 较低风险
       /███████████████████████████████████████\ - Safe Harbor 保护
      /█████████████████████████████████████████\- 完整正当程序
     ─────────────────────────────────────────────
```

---

### 六、一句话总结

> **印度是全球对域名注册商最具"敌意"的法律环境**：它拥有最激进的动态禁令机制（Dynamic/+/++）、最短的响应时限（72小时）、最弱的安全港保护、最强的域外管辖主张，以及全球唯一的"整体服务封禁"先例。对于任何在印度市场有业务或用户的域名注册商而言，合规风险极高。

---

### 七、参考法规与资料链接汇总

#### 📜 官方法条

| 法规 | 来源 | 链接 |
|------|------|------|
| IT Act 2000 Section 69A 原文 | IT Law India | https://www.itlaw.in/section-69a-power-to-issue-directions-for-blocking-for-public-access-of-any-information-through-any-computer-resource/ |
| IT Act 2000 Section 79 分析 | Indian Kanoon | https://indiankanoon.org/doc/47479491/ |

#### 📚 官方判决书（Indian Kanoon / CaseMine）

| 案例 | 案号 | 链接 |
|------|------|------|
| UTV v. 1337x.to (Dynamic Injunction 首案) | CS(COMM) 724/2017 | https://indiankanoon.org/doc/47479491/ |
| UTV v. 1337x.to (CaseMine) | CS(COMM) 724/2017 | https://www.casemine.com/judgement/in/5caf6c229eff430a7aaa7b87 |
| Universal Studios v. Dotmovies (Dynamic+ Injunction) | CS(COMM) 514/2023 | https://indiankanoon.org/doc/156457058/ |
| Snapdeal v. GoDaddy (Safe Harbour) | - | https://indiankanoon.org/doc/11734158/ |
| Satyam Infoway v. Sifynet (域名商标) | 最高法院 | https://indiankanoon.org/doc/1587012/ |
| Rahul Mishra v. John Doe (2024) | CS(COMM) 1194/2024 | https://indiankanoon.org/doc/76823667/ |
| Shreya Singhal v. Union of India | 最高法院 | https://indiankanoon.org/doc/110813550/ |

#### ⚖️ 权威律所文章

| 律所/机构 | 主题 | 链接 |
|----------|------|------|
| **Lakshmikumaran & Sridharan** | UTV 案 Dynamic Injunction 分析 | https://www.lakshmisri.com/insights/articles/dynamic-injunction-against-rogue-websites-in-utv-case-balanced-remedy-or-excessive-enforcement |
| **ALG India Law Offices** | Section 151 CPC 与 Dynamic Injunction | https://www.algindia.com/are-dynamic-injunctions-permissible-under-section-151-cpc/ |
| **ALG India Law Offices** | 注册商能否封锁访问分析 | https://www.algindia.com/domain-name-registrars-cannot-block-access-to-or-ensure-the-continued-suspension-of-domain-names/ |
| **Mondaq (Vaish Associates)** | IT Act 网站封锁权力分析 | https://www.mondaq.com/india/it-and-internet/1475400/website-ip-address-blocking-under-the-indian-it-rules-law-in-india |
| **Mondaq** | Dynamic Injunction 演进 | https://www.mondaq.com/india/trademark/1662760/the-evolving-pace-of-dynamic-injunctions-in-the-digital-age |
| **Mondaq** | 中介安全港重新定义 | https://www.mondaq.com/india/privacy-protection/1075410/redefining-intermediary-safe-harbour-free-speech-and-privacy-concerns-in-india |
| **Mondaq** | 商标保护与 Dynamic Injunction | https://www.mondaq.com/india/trademark/1684414/safeguarding-well-known-trademarks-in-the-digital-age-with-dynamic-injunctions-and-summary-judgments |
| **Managing IP** | Dynamic to Superlative Injunction | https://www.managingip.com/article/2f71ano5zuw2pqzcncv7k/sponsored-content/from-dynamic-to-superlative-indian-courts-adapt-injunctive-relief-to-digital-infringement |
| **SpicyIP (知识产权法律博客)** | 预防性域名禁令分析 | https://spicyip.com/2025/08/domain-name-ring-fencing-evaluation-of-madras-hcs-new-pre-emptive-twist-to-dynamic-injunctions.html |
| **C&C IP** | Dynamic Injunction 机制解析 | https://www.candcip.com/single-post/dynamic-injunctions-a-novel-species-of-injunctions-in-the-realm-of-digital-piracy-introduction |
| **Bar and Bench** | Safe Harbour 例外分析 | https://www.barandbench.com/columns/safe-harbour-exemptions-available-to-intermediaries-exception-or-norm-under-digital-india-act |
| **Chandrawat & Partners** | DNR Safe Harbour 丧失分析 | https://chandrawatpartners.co/dnrs-to-lose-safe-harbour-for-trademark-abuse-delhi-high-court-issues-sweeping-directions-to-curb-online-fraud/ |
| **SFLC.in** | UTV 案案例研究 | https://sflc.in/policies-and-cases/utv-software-communication-ltd-ors-v-1337x-to-ors-dynamic-injunctions-for-website-blocking-case/ |
| **CIS India** | 网站封锁合法性分析 | https://cis-india.org/internet-governance/blog/the-legal-validity-of-internet-bans-part-ii |
| **Columbia Global Freedom of Expression** | UTV 案言论自由分析 | https://globalfreedomofexpression.columbia.edu/cases/utv-software-communications-ltd-v-1337x-to/ |

#### 📰 SCC Online / 24Law.in（法律新闻/判决分析）

| 主题 | 链接 |
|------|------|
| Universal Studios Dynamic Injunction | https://www.scconline.com/blog/post/2024/05/23/delhi-high-court-grants-dynamic-injunction-in-favour-universal-studios-against-infringing-websites-protect-copyrighted-work-legal-news/ |
| 106 Rogue Websites Dynamic+ Injunction | https://24law.in/story/delhi-high-court-grants-dynamic-injunction-against-rogue-websites-to-protect-copyrighted-content-of |
| JioStar Dynamic+ Injunction | https://www.scconline.com/blog/post/2025/07/02/delhi-high-court-dynamic-injunction-jiostar-india-england-2025-streaming-legal-news/ |

---

## 附录：案例链接汇总

### GoDaddy 案例

| 案例 | 地区 | 链接 |
|------|------|------|
| Chanel 商标案 | 🇺🇸 美国 | https://www.wired.com/2011/11/chanel-trademark |
| JotForm 事件 | 🇺🇸 美国 | https://arstechnica.com/tech-policy/2012/02/secret-service-asks-for-shutdown-of-legit-website-over-user-content-godaddy-complies/ |
| Leo India Films v. GoDaddy | 🇺🇸 美国 | https://www.casemine.com/judgement/us/5e535b6b4653d00b253ec7d6 |
| Tamaris DMCA 传票案 | 🇺🇸 美国 | https://worldjusticenews.com/news/2025/12/18/godaddy-ordered-to-unmask-owners-of-over-100-alleged-copyright-infringing-domains/ |
| uBID v. GoDaddy | 🇺🇸 美国 | https://caselaw.findlaw.com/us-7th-circuit/1539590.html |
| 968.com 域名案 | 🇺🇸 美国 | https://domainnamewire.com/2023/04/26/court-dismisses-case-against-godaddy-over-968-com-domain/ |
| Amul 品牌案 | 🇮🇳 印度 | https://www.medianama.com/2020/08/223-godaddy-amul-domain-registrars-delhi-hc/ |
| Swiggy 商标案 | 🇮🇳 印度 | https://indiankanoon.org/doc/116900066/ |
| Baazi Group 案 | 🇮🇳 印度 | https://legal.economictimes.indiatimes.com/news/litigation/delhi-high-court-takes-action-against-infringing-gambling-websites-and-domain-names/118496817 |
| Delhi HC 警告案 | 🇮🇳 印度 | https://telecom.economictimes.indiatimes.com/news/act-against-internet-domain-name-registrars-not-complying-with-court-orders-delhi-hc-to-centre/95456336 |
| Snapdeal v. GoDaddy | 🇮🇳 印度 | https://www.scconline.com/blog/post/2022/07/18/delhi-high-court-refuses-blanket-injunction-against-godaddy-from-registering-snapdeal-trademark-every-infringement-must-be-petitioned-separately/ |

### Cloudflare 案例

| 案例 | 地区 | 链接 |
|------|------|------|
| Grooveshark 商标案 | 🇺🇸 美国 | https://www.eff.org/deeplinks/2015/07/victory-cloudflare-against-sopa-court-order-internet-service-doesnt-have-police |
| Shift4 Payments 案 | 🇺🇸 美国 | https://law.justia.com/cases/federal/district-courts/california/candce/4%3A2025cv06724/454351/23 |
| Mon Cheri Bridals 案 | 🇺🇸 美国 | https://arstechnica.com/tech-policy/2021/10/cloudflare-doesnt-have-to-cut-off-copyright-infringing-websites-judge-rules/ |
| Guardaserie 案 | 🇪🇺 意大利 | https://torrentfreak.com/court-orders-cloudflare-to-block-and-identify-pirate-site-customer-241019/ |
| Universal 音乐案 | 🇪🇺 德国 | https://blog.cloudflare.com/latest-copyright-decision-in-germany-rejects-blocking-through-global-dns-resolvers/ |

### Namecheap 案例

| 案例 | 地区 | 链接 |
|------|------|------|
| 用户域名被锁定报告 | 🇺🇸 美国 | https://www.reddit.com/r/NameCheap/comments/1lh4h6o |
| **Infante v. Namecheap (TRO 案)** | 🇺🇸 美国 | https://dockets.justia.com/docket/arizona/azdce/2%3A2025cv02537/1451097 |
| Infante v. Namecheap (判决书) | 🇺🇸 美国 | https://www.casemine.com/judgement/us/688db05def417aceda15738d |
| Delhi HC 调查案 | 🇮🇳 印度 | https://telecom.economictimes.indiatimes.com/news/act-against-internet-domain-name-registrars-not-complying-with-court-orders-delhi-hc-to-centre/95456336 |
| Namecheap 印度封锁 | 🇮🇳 印度 | https://en.wikipedia.org/wiki/Namecheap |
| **JioStar India Dynamic+ 禁令案** | 🇮🇳 印度 | https://www.scconline.com/blog/post/2025/07/02/delhi-high-court-dynamic-injunction-jiostar-india-england-2025-streaming-legal-news/ |
| DAZN Dynamic+ 禁令案 | 🇮🇳 印度 | https://24law.in/story/delhi-high-court-grants-dynamic-plus-ex-parte-injunction-to-dazn-blocks-websites-illegally-streaming |

### 印度 Dynamic Injunction 框架相关

| 资料 | 类型 | 链接 |
|------|------|------|
| Dynamic Injunction 首创案例分析 | 研究报告 | https://itif.org/publications/2019/05/29/india-and-website-blocking-courts-allow-dynamic-injunctions-fight-digital/ |
| Dynamic to Superlative Injunction 发展 | 法律分析 | https://www.managingip.com/article/2f71ano5zuw2pqzcncv7k/sponsored-content/from-dynamic-to-superlative-indian-courts-adapt-injunctive-relief-to-digital-infringement |
| Warner Bros./Netflix Dynamic+ 案 | 新闻报道 | https://www.medianama.com/2026/01/223-delhi-hc-dynamic-injunction-piracy-sites-illegally-streaming-netflix-warner-bros-content/ |
| Reliance v. Anonymous Sellers 案 | 法律分析 | https://chambers.com/articles/delhi-high-court-s-dynamic-injunction-in-reliance-v-anonymous-sellers-a-new-template-for-trademark |
| Tata Dynamic Injunction 案 | 新闻报道 | https://www.storyboard18.com/how-it-works/delhi-hc-issues-dynamic-injunction-to-tata-against-trademark-infringement-74770.htm |
| DNR Safe Harbour 削弱分析 | 法律分析 | https://chandrawatpartners.co/dnrs-to-lose-safe-harbour-for-trademark-abuse-delhi-high-court-issues-sweeping-directions-to-curb-online-fraud/ |
| e-KYC 强制要求报道 | 新闻报道 | https://timesofindia.indiatimes.com/city/delhi/hc-mandates-strict-e-kyc-for-domain-name-registrants-to-curb-cyber-fraud/articleshow/126238148.cms |
| 跨境执行挑战分析 | 论坛讨论 | https://techenclave.com/t/disney-netflix-crunchyroll-push-global-pirate-site-takedowns-via-indian-court/411904 |
| Dynamic Injunction 2026 回顾 | 年度综述 | https://www.worldtrademarkreview.com/review/the-trademark-litigation-review/2026/article/india-dynamic-injunctions-prove-critical-in-the-fight-against-digital-piracy |

---

*本文档基于公开资料整理，仅供参考，不构成法律建议。*

*最后更新：2026年1月21日*
